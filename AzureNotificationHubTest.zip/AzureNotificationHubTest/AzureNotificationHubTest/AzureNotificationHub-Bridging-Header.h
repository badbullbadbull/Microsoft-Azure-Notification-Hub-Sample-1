//
//  AzureNotificationHub-Bridging-Header.h
//  AzureNotificationHubTest
//
//  Created by Moo on 2016/2/27.
//  Copyright © 2016年 Moo. All rights reserved.
//

#ifndef AzureNotificationHub_Bridging_Header_h
#define AzureNotificationHub_Bridging_Header_h

/* WindowsAzureMobileServices */
#import "WindowsAzureMobileServices/MSClient.h"
#import "WindowsAzureMobileServices/MSError.h"
#import "WindowsAzureMobileServices/MSFilter.h"
#import "WindowsAzureMobileServices/MSLoginController.h"
#import "WindowsAzureMobileServices/MSPush.h"
#import "WindowsAzureMobileServices/MSQuery.h"
#import "WindowsAzureMobileServices/MSTable.h"
#import "WindowsAzureMobileServices/MSUser.h"
#import "WindowsAzureMobileServices/WindowsAzureMobileServices.h"

/* WindowsAzureMessaging */
#import "WindowsAzureMessaging/SBConnectionString.h"
#import "WindowsAzureMessaging/SBLocalStorage.h"
#import "WindowsAzureMessaging/SBNotificationHub.h"
#import "WindowsAzureMessaging/SBRegistration.h"
#import "WindowsAzureMessaging/SBStoredRegistrationEntry.h"
#import "WindowsAzureMessaging/SBTokenProvider.h"
#import "WindowsAzureMessaging/WindowsAzureMessaging.h"


#endif /* AzureNotificationHub_Bridging_Header_h */
