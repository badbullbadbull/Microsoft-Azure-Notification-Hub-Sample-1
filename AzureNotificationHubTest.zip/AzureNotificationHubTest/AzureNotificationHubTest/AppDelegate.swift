//
//  AppDelegate.swift
//  AzureNotificationHubTest
//
//  Created by Moo on 2016/2/27.
//  Copyright © 2016年 Moo. All rights reserved.
//

import UIKit
import Foundation

@UIApplicationMain
class AppDelegate: UIResponder, UIApplicationDelegate {

    var window: UIWindow?
    var apnsToken:NSData = NSData()
    lazy var messageBoxVC:UIViewController = UIViewController()


    func application(application: UIApplication, didFinishLaunchingWithOptions launchOptions: [NSObject: AnyObject]?) -> Bool {
        // Override point for customization after application launch.
        
        //設定Notification告警方式
        let notificationSetting:UIUserNotificationSettings = UIUserNotificationSettings(forTypes: [UIUserNotificationType.Sound, UIUserNotificationType.Alert, UIUserNotificationType.Badge], categories: nil)
        
        //設定Notification告警
        UIApplication.sharedApplication().registerUserNotificationSettings(notificationSetting)
        
        //向APNS註冊
        UIApplication.sharedApplication().registerForRemoteNotifications()
        
        //產生一個View來顯示MessageBox裡的alertController
        self.messageBoxVC = MessageBoxViewController(nibName:"MessageBoxView",bundle:nil)
        window?.rootViewController = messageBoxVC
        window?.makeKeyAndVisible()
        
        return true
    }

    func applicationWillResignActive(application: UIApplication) {
        // Sent when the application is about to move from active to inactive state. This can occur for certain types of temporary interruptions (such as an incoming phone call or SMS message) or when the user quits the application and it begins the transition to the background state.
        // Use this method to pause ongoing tasks, disable timers, and throttle down OpenGL ES frame rates. Games should use this method to pause the game.
    }

    func applicationDidEnterBackground(application: UIApplication) {
        // Use this method to release shared resources, save user data, invalidate timers, and store enough application state information to restore your application to its current state in case it is terminated later.
        // If your application supports background execution, this method is called instead of applicationWillTerminate: when the user quits.
    }

    func applicationWillEnterForeground(application: UIApplication) {
        // Called as part of the transition from the background to the inactive state; here you can undo many of the changes made on entering the background.
    }

    func applicationDidBecomeActive(application: UIApplication) {
        // Restart any tasks that were paused (or not yet started) while the application was inactive. If the application was previously in the background, optionally refresh the user interface.
    }

    func applicationWillTerminate(application: UIApplication) {
        // Called when the application is about to terminate. Save data if appropriate. See also applicationDidEnterBackground:.
    }
    
    //MARK: - 提供裝置權杖給通知中樞，讓通知中樞能夠傳送通知
    func application(application: UIApplication, didRegisterForRemoteNotificationsWithDeviceToken deviceToken: NSData) {
        
        self.apnsToken = deviceToken
        print("apnsToken = \(self.apnsToken)")
        
        //要取出connectionString & notificationHubPath的值
        //以Dictionary方式取出, 從AzureString.plist
        let azureDict = NSDictionary(contentsOfFile: NSBundle.mainBundle().pathForResource("AzureString", ofType: "plist")!)
        
        //透過key取出Value
        let connectionString = azureDict?.valueForKey("HUBLISTENACCESS") as! String
        let notificationHubPath = azureDict?.valueForKey("HUBNAME") as! String
        
        //指定Azure Notification Hub
        let azureNotificationHub:SBNotificationHub = SBNotificationHub(connectionString: connectionString, notificationHubPath: notificationHubPath)
        
        //將APNS DeviceToken交付給Azure Notification Hub
        azureNotificationHub.registerNativeWithDeviceToken(apnsToken, tags: nil, completion: { (error) -> Void in
            if error != nil{
                print("APNS DeviceToken交付給Azure的error = \(error)")
            }else{
                print("APNS DeviceToken交付給Azure的error = \(error)")
                print("apnsToken = \(self.apnsToken)")
                print("APNS DeviceToken交付給Azure = Success!")
                self.MessageBox("Registration Status", message: "Registered")
            }
            })
    }
    
    //MARK: - 應用程式在作用中時收到通知
    func application(application: UIApplication, didReceiveRemoteNotification userInfo: [NSObject : AnyObject]) {
        let dict:NSDictionary = userInfo
        let tempMessage1 = dict.objectForKey("aps")
        let tempMessageString = tempMessage1?.objectForKey("alert") as! String
        
        self.MessageBox("Notification", message: tempMessageString)
        
    }
    
    //MARK: - 錯誤訊息框
    func MessageBox(title: String, message messageText: String){
        //設定alertController
        //主體形式
        let alertController = UIAlertController(title: title, message: messageText, preferredStyle: UIAlertControllerStyle.ActionSheet)
                
        //設定取消並加入
        let cancelAction = UIAlertAction(title: "Cancel", style: UIAlertActionStyle.Cancel, handler: nil)

        alertController.addAction(cancelAction)
                
        //加入新頁面並呈現
//        self.presentViewController(alertController, animated: true, completion: <#T##(() -> Void)?##(() -> Void)?##() -> Void#>)
        
        
        self.messageBoxVC.presentViewController(alertController, animated: true, completion: nil)

            }


}

